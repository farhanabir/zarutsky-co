---
title: "Cases"
permalink: "{{ page.fileSlug }}/index.html"
layout: "cases.html"
slug: "cases"
tags: "pages"
seo:
  title: "Zarutsky&Co"
  description: "Разработка сайтов на высшем уровне. Стильные сайты с проработанной структурой, правильным позиционированием продукта, крутой графикой и креативной концепцией."
  og_title: "Zarutsky&Co"
  og_description: "Разработка сайтов на высшем уровне. Стильные сайты с проработанной структурой, правильным позиционированием продукта, крутой графикой и креативной концепцией."
  og_type: "website"
  twitter_card: "summary_large_image"
---


