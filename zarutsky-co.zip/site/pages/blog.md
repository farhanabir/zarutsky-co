---
title: "Blog"
permalink: "{{ page.fileSlug }}/index.html"
layout: "blog.html"
slug: "blog"
tags: "pages"
seo:
  title: "Zarutsky&Co"
  description: "Все самое интересное про дизайн."
  og_title: "Zarutsky&Co"
  og_description: "Все самое интересное про дизайн."
  og_type: "website"
  twitter_card: "summary_large_image"
---


