---
_archived: false
_draft: false
cover-project:
  url: "https://uploads-ssl.webflow.com/606486244d40e3306f107fe4/60648d56e1df041351f18c8f_Group%20106.jpg"
  alt: ""
created-on: "2021-03-31T15:03:52.014Z"
problem-solution: "Главной задачей проекта стояла полная переработка всей логики и дизайна сайта сети салонов Лазерной медицины \"МЕДЛАЗ\". В сети салонов вы можете получить консультацию по интересующим вопросам и успешно решить волнующие вас проблемы. Сеть салонов «Медлаз» располагает обширным набором современного лазерного оборудования, что позволяет решать каждую конкретную задачу уверенно, быстро и эффективно!"
name: "Медлаз Тест Copy 4"
slug: "medlaz-test-copy-4"
project-color: "#e9ad98"
updated-on: "2021-04-03T16:16:41.429Z"
description: "Сайт для сети клиник лазерной медицины"
year: "2021"
published-on: null
tags: "projects"
layout: "single-projects.html"
---

![](https://uploads-ssl.webflow.com/606486244d40e3306f107fe4/60648ef0e2749525c54a1a1a_Medlaz_01.jpg)
